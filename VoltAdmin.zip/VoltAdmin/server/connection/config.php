<?php

$conn = mysqli_connect("database-1.ctsrely4bvgo.ap-south-1.rds.amazonaws.com", "admin", "pawan2244", "Algo");

if (!$conn) {
    echo "Connection failed";
}
?>