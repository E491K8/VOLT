<?php

session_start();

include_once("../connection/config.php");
date_default_timezone_set("Asia/Calcutta");

$timestamp = date("Y-m-d H:i:s");


if (isset($_POST["login"])) {

	$ssid = mysqli_real_escape_string($conn, $_POST["ssid"]);
	$password = mysqli_real_escape_string($conn, md5($_POST["password"]));

	$sql = "select * from users where ssid = '$ssid' and password = '$password'";  
	$result = mysqli_query($conn, $sql);  
	$row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
	$count = mysqli_num_rows($result);  
	  
	if($count == 1){  
        $_SESSION['SESSION_SSID'] = $row['ssid'];
         header("Location: ../../pages/transactions.php");

	} else {
		echo "<script>alert('Invalid SSID or Password! Please try again')</script>";
	} 
}

?>