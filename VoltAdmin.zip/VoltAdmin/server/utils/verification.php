<?php

session_start();

include_once("../connection/config.php");
$reg_id = $_SESSION['SESSION_ORDERID'];

if (isset($_POST["verify"])) {

	$otp = mysqli_real_escape_string($conn, $_POST["otp"]);

	$sql = "select * from orders where order_id = '$reg_id' and otp = '$otp'";  
	$result = mysqli_query($conn, $sql);  
	$row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
	$count = mysqli_num_rows($result);  
	  
	if($count == 1){  
		echo "<script>alert('Redirecting....')</script>";  

		$_SESSION["SESSION_SSID"] = $row['ssid'];
        header("Location: ../../index.html");
		
	}  
	else{  
		echo "<script>alert('Incorrect OTP please try again!')</script>";  
	}     
}

?>